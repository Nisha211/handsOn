package com.code2;

public class Account {
	protected String accountNumber;
	protected double balance;
	protected String acctHolderName;
	public Account() {
		
	}
	public Account(String accountNumber, double balance, String acctHolderName) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.acctHolderName = acctHolderName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getAcctHolderName() {
		return acctHolderName;
	}
	public void setAcctHolderName(String acctHolderName) {
		this.acctHolderName = acctHolderName;
	}
	
	
	
	
	

	

}
