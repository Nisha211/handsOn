package com.code2;

public class AccountBO{
	public FixedAccount getAccountdetail(String detail) {
		FixedAccount f=new FixedAccount();
		String details[]=detail.split(",");
		f.setAccountNumber(details[0]);
		f.setBalance(Double.parseDouble(details[1]));
		f.setAcctHolderName(details[2]);
		f.setMinimumBalance(Double.parseDouble(details[3]));
		f.setLockingPeriod(Integer.parseInt(details[4]));
		
		
		return f;
		
		
		
	}
	

}
