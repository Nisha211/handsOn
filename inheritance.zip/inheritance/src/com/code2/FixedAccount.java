package com.code2;

public class FixedAccount extends SavingAccount{
	private int lockingPeriod;
	
	public FixedAccount() {
		
	}

	public FixedAccount(int lockingPeriod) {
		super();
		this.lockingPeriod = lockingPeriod;
	}

	public int getLockingPeriod() {
		return lockingPeriod;
	}

	public void setLockingPeriod(int lockingPeriod) {
		this.lockingPeriod = lockingPeriod;
	}
	

}
