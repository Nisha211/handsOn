package com.code2;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		String str="acct001,5456.10,tonyblae,500,10";
		AccountBO a=new AccountBO();
		FixedAccount fa=a.getAccountdetail(str);
		System.out.format("%-20s, %-10s ,%-20s ,%-10s ,%s",fa.getAccountNumber() ,fa.getBalance() ,fa.getAcctHolderName(),fa.getMinimumBalance(),fa.getLockingPeriod());
		
	}

}
