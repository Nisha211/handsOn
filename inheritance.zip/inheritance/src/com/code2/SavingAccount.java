package com.code2;

public class SavingAccount extends Account {
	protected double minimumBalance;
	
	public SavingAccount() {
		
	}

	public double getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	public SavingAccount(double minimumBalance) {
		super();
		this.minimumBalance = minimumBalance;
	}
	

}
