package com.code4;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		Stall obj=new Stall();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name of the stall");
		String a=sc.nextLine();
		System.out.println("enter the detain of the stall");
		String b=sc.nextLine();
		System.out.println("enter the owner name of the stall");
		String c=sc.nextLine();
		System.out.println("enter the type of the stall");
		String d=sc.nextLine();
		System.out.println("enter the size of the stall in square feet");
	    int e=sc.nextInt();
	    System.out.println("do you have tv");
	    int f=sc.nextInt();
	    if(f==1)
	    {
	    	System.out.println("enter no of tv");
	    	int g=sc.nextInt();
	    	obj.computeCost(d, e,f);
	    	
	    }
	    else
	    {
	    	obj.computeCost(d, e);
	    }
	    
		
		
		
		
	 
		
	}

}
