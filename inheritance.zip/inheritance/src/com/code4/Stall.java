package com.code4;

public class Stall {
	public double computeCost(String stallType, Integer squareFeet ) {
		double price=0;
		if(stallType.equals("platinum")) {
			price=squareFeet*200;
			System.out.println(price);
		}
		else if(stallType.equals("diamond")) {
			price=squareFeet*150;
			System.out.println(price);
		}
		else if(stallType.equals("gold")) {
			price=squareFeet*100;
			System.out.println(price);
		}
		else {
			System.out.println("invalid");
		}
		return price;
	}
	
	public double computeCost(String stallType,Integer squareFeet,Integer noOfTv) {
		double price=0;
		double total=0;
		if(stallType.equals("platinum")) {
			price=squareFeet*200;
			total=price+(noOfTv*10000);
			System.out.println(total);
		}
		else if(stallType.equals("diamond")) {
			price=squareFeet*150;
			total=price+(noOfTv*10000);
			System.out.println(total);
		}
		else if(stallType.equals("gold")) {
			price=squareFeet*100;
			total=price+(noOfTv*10000);
			System.out.println(total);
		}
		else {
			System.out.println("invalid");
		}
		return total;
	}
		
	}


