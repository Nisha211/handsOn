package com.code5;

public class Circle extends Shape{
	private double radius;
	public Circle() {
		
	}

	public Circle(double radius) {
		super();
		this.radius = radius;
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}
public void computeArea() {
	double circle=(22/7)*radius*radius;
	System.out.println(circle);
		
	}
}
