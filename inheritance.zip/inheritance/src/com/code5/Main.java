package com.code5;
import java.util.*;


public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Circle,2.rectangle,3.triangle");
		int a=sc.nextInt();
		sc.nextLine();
		switch(a) {
		case 1:
			System.out.println("enter radius");
			double radius=sc.nextDouble();
			sc.nextLine();
			Circle c1=new Circle();
			c1.setRadius(radius);
			c1.computeArea();
			break;
		case 2:
			System.out.println("enter length& breadth");
			double length=sc.nextDouble();
			sc.nextLine();
			double breadth=sc.nextDouble();
			sc.nextLine();
			Rectangle r1=new Rectangle();
			r1.setLength(length);
			r1.setBreadth(breadth);
			r1.computeArea();
			break;
			
		case 3:
			System.out.println("enter base &height");
			double base=sc.nextDouble();
			sc.nextLine();
			double height=sc.nextDouble();
			sc.nextLine();
			Triangle t=new Triangle();
			t.setBase(base);
			t.setHeight(height);
			t.computeArea();
			// TODO Auto-generated method stub

	}
	}

}
