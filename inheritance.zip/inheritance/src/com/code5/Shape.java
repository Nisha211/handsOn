package com.code5;

public class Shape {
	protected double area;
	public Shape() {
		
	}
	
	public Shape(double area) {
		super();
		this.area = area;
	}


	public void computeArea() {
		
	}

}
