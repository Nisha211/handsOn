package inheritance;
import java.util.*;
public class Main{

	public static void main(String[] args) {
		String str;
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		sc.nextLine();
		if(a==1) {
			System.out.println("enter the account details");
			str=sc.nextLine();
			String details[]=str.split(",");
			SavingsAccount s1=new SavingsAccount(details[0],details[1],details[2],details[3]);
			s1.display();
		}
		else {
			System.out.println("enter the account details");
			str=sc.nextLine();
			String details[]=str.split(",");
			Current_Account c1=new Current_Account(details[0],details[1],details[2],details[3]);
			c1.display();	
			
		}
		
		
		
	}

}
